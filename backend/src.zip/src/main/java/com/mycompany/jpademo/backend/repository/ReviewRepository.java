package com.mycompany.jpademo.backend.repository;

import com.mycompany.jpademo.backend.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {

    Optional<Review> findByDiagnosisSessionSessionId(Integer sessionId);
}